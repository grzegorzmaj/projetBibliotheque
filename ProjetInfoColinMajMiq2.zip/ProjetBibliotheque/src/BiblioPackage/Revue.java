package BiblioPackage;



/**
 * Class Revue
 */
public class Revue extends Ressource {

  //
    // Fields
    //
  //
    // Constructors
    //
    public Revue(String t, String aut, String cat, String nation, String ref, String desc, int nb) {
        super(t, aut, cat, nation, ref, desc, nb);
    }

    public Revue(String t, String aut, String cat, String nation, String ref, String desc, int nb, int nbD, int nbR) {
        super(t, aut, cat, nation, ref, desc, nb, nbD, nbR);
    }

  //
    // Methods
    //
  //
    // Accessor methods
    //
  //
    // Other methods
    //
}
