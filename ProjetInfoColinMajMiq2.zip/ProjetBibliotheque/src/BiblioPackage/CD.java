package BiblioPackage;



/**
 * Class CD
 */
public class CD extends Ressource {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public CD (String t, String aut, String cat, String nation, String ref, String desc, int nb) {
      super(t,aut,cat,nation,ref,desc,nb);
  }
  
  public CD (String t, String aut, String cat, String nation, String ref, String desc, int nb, int nbD, int nbR) {
      super(t,aut,cat,nation,ref,desc,nb, nbD, nbR);
  }
  
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

}
