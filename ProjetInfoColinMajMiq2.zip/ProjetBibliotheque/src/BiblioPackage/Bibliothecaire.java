package BiblioPackage;

import java.util.*;


/**
 * Class Bibliothecaire
 */
public class Bibliothecaire extends Personne {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public Bibliothecaire (String n, String p, String a, String dn, int tel, String am, int num, String mdp) { 
    super(n,p,a,dn,tel,am, num, mdp);
  }
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

}
