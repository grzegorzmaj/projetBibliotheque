package BiblioPackage;


import java.util.*;


/**
 * Class Date
 */
public class Date {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public Date () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

}
