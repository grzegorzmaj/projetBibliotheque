package BiblioPackage;



/**
 * Class DVD
 */
public class DVD extends Ressource {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public DVD (String t, String aut, String cat, String nation, String ref, String desc, int nb) {
      super(t,aut,cat,nation,ref,desc,nb);
}
  public DVD (String t, String aut, String cat, String nation, String ref, String desc, int nb, int nbD, int nbR) {
      super(t,aut,cat,nation,ref,desc,nb,nbD,nbR);
}
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

}
